package com.example.lab3.data

import java.io.Serializable

data class Quotes(val quotes:List<Quote>) : Serializable

